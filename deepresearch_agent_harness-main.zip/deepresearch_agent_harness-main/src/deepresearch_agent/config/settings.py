import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# 统一加载环境变量，确保配置来源一致
load_dotenv()


def _get_env_int(key: str, default: Optional[int]) -> Optional[int]:
    """获取整型环境变量，未设置时返回默认值"""
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"环境变量 {key} 需要整数值，但当前为 {raw}") from exc


def _get_env_float(key: str, default: Optional[float]) -> Optional[float]:
    """获取浮点型环境变量，未设置时返回默认值"""
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise ValueError(f"环境变量 {key} 需要浮点值，但当前为 {raw}") from exc


def _get_env_bool(key: str, default: bool) -> bool:
    """获取布尔型环境变量，支持 true/false/1/0 表达式"""
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    return raw.lower() in {"1", "true", "yes", "y", "on"}


def _get_env_choice(key: str, choices: set[str], default: str) -> str:
    """获取有限集合中的字符串配置，未设置时返回默认值"""
    raw = os.getenv(key)
    if raw is None or raw.strip() == "":
        return default
    value = raw.strip().lower()
    if value not in choices:
        raise ValueError(
            f"环境变量 {key} 必须为 {', '.join(sorted(choices))} 之一，但当前为 {raw}"
        )
    return value


def _require_positive(key: str, value: int) -> int:
    if value < 1:
        raise ValueError(f"环境变量 {key} 必须大于等于 1")
    return value


# ===== 基础路径设置 =====

BASE_DIR = Path(__file__).resolve().parent.parent  # deepresearch_agent包目录（src/deepresearch_agent）
PROJECT_ROOT = BASE_DIR.parent.parent  # 项目根目录（src 布局：包目录上溯两级）
FILES_DIR = PROJECT_ROOT / "files"
FILE_REGISTRY_PATH = PROJECT_ROOT / "file_registry.json"  # 文件注册表路径

# ===== 知识库与系统参数 =====

KB_NAME = "临床医学"  # 知识库主题，用于deepsearch
workers = _get_env_int("FASTAPI_WORKERS", 1) or 1  # 本地 MVP 强制单进程
LOCAL_MVP_SINGLE_WORKER = workers == 1

# ===== 本地 MVP 应用与持久化配置 =====

APP_ENV = os.getenv("APP_ENV", "local")
APP_HOST = os.getenv("APP_HOST", "127.0.0.1")
APP_PORT = _require_positive("APP_PORT", _get_env_int("APP_PORT", 8000) or 8000)
FRONTEND_ORIGINS = tuple(
    item.strip()
    # 默认同时放行 localhost 与 127.0.0.1：仓库内 vite.config.ts 将 dev server
    # 绑定在 http://127.0.0.1:5173，仅放行 localhost 会导致浏览器 CORS 预检被拒。
    for item in os.getenv(
        "FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
    ).split(",")
    if item.strip()
)
APP_DATABASE_URL = os.getenv(
    "APP_DATABASE_URL", "sqlite+aiosqlite:///./data/app.db"
).strip()
ARTIFACT_ROOT = Path(os.getenv("ARTIFACT_ROOT", PROJECT_ROOT / "data" / "artifacts")).expanduser()
SKILLS_ROOT = Path(os.getenv("SKILLS_ROOT", PROJECT_ROOT / "skills")).expanduser()
AUTO_RESUME_RUNS = _get_env_bool("AUTO_RESUME_RUNS", True)
CONTEXT_MAX_CHARS = _require_positive("CONTEXT_MAX_CHARS", _get_env_int("CONTEXT_MAX_CHARS", 16000) or 16000)
CONTEXT_RECENT_TURNS = _require_positive("CONTEXT_RECENT_TURNS", _get_env_int("CONTEXT_RECENT_TURNS", 8) or 8)
CONTEXT_MAX_TOKENS = _require_positive("CONTEXT_MAX_TOKENS", _get_env_int("CONTEXT_MAX_TOKENS", 12000) or 12000)
CONTEXT_COMPRESSION_THRESHOLD_TOKENS = _require_positive("CONTEXT_COMPRESSION_THRESHOLD_TOKENS", _get_env_int("CONTEXT_COMPRESSION_THRESHOLD_TOKENS", 8000) or 8000)
CONTEXT_COMPRESSION_THRESHOLD_RATIO = _get_env_float("CONTEXT_COMPRESSION_THRESHOLD_RATIO", 0.50) or 0.50
CONTEXT_COMPRESSION_TARGET_TOKENS = _require_positive("CONTEXT_COMPRESSION_TARGET_TOKENS", _get_env_int("CONTEXT_COMPRESSION_TARGET_TOKENS", 2000) or 2000)
CONTEXT_PROTECT_RECENT_MESSAGES = _require_positive("CONTEXT_PROTECT_RECENT_MESSAGES", _get_env_int("CONTEXT_PROTECT_RECENT_MESSAGES", 12) or 12)
SESSION_SEARCH_TOP_K = _require_positive("SESSION_SEARCH_TOP_K", _get_env_int("SESSION_SEARCH_TOP_K", 3) or 3)
SESSION_SEARCH_WINDOW = _require_positive("SESSION_SEARCH_WINDOW", _get_env_int("SESSION_SEARCH_WINDOW", 5) or 5)
MEMORY_USER_MAX_TOKENS = _require_positive("MEMORY_USER_MAX_TOKENS", _get_env_int("MEMORY_USER_MAX_TOKENS", 500) or 500)
MEMORY_PROJECT_MAX_TOKENS = _require_positive("MEMORY_PROJECT_MAX_TOKENS", _get_env_int("MEMORY_PROJECT_MAX_TOKENS", 800) or 800)
MEMORY_USER_MAX_CHARS = _require_positive("MEMORY_USER_MAX_CHARS", _get_env_int("MEMORY_USER_MAX_CHARS", 1375) or 1375)
MEMORY_PROJECT_MAX_CHARS = _require_positive("MEMORY_PROJECT_MAX_CHARS", _get_env_int("MEMORY_PROJECT_MAX_CHARS", 2200) or 2200)
MEMORY_WRITE_APPROVAL = _get_env_bool("MEMORY_WRITE_APPROVAL", True)
MEMORY_BACKGROUND_REVIEW_ENABLED = _get_env_bool("MEMORY_BACKGROUND_REVIEW_ENABLED", True)
# Deprecated compatibility aliases. New code uses token pressure and curated-store limits.
SESSION_SUMMARY_THRESHOLD_MESSAGES = _require_positive("SESSION_SUMMARY_THRESHOLD_MESSAGES", _get_env_int("SESSION_SUMMARY_THRESHOLD_MESSAGES", 20) or 20)
SEMANTIC_MEMORY_MAX_CHARS = MEMORY_PROJECT_MAX_CHARS

TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "")
TAVILY_SEARCH_DEPTH = _get_env_choice("TAVILY_SEARCH_DEPTH", {"basic", "advanced"}, "advanced")
TAVILY_MAX_RESULTS = _require_positive("TAVILY_MAX_RESULTS", _get_env_int("TAVILY_MAX_RESULTS", 5) or 5)
TAVILY_TIMEOUT_SECONDS = _require_positive("TAVILY_TIMEOUT_SECONDS", _get_env_int("TAVILY_TIMEOUT_SECONDS", 45) or 45)
TAVILY_CACHE_TTL_SECONDS = _require_positive("TAVILY_CACHE_TTL_SECONDS", _get_env_int("TAVILY_CACHE_TTL_SECONDS", 86400) or 86400)

HARNESS_BUDGETS = {
    "wall_time_seconds": _require_positive("RUN_MAX_WALL_TIME_SECONDS", _get_env_int("RUN_MAX_WALL_TIME_SECONDS", 1800) or 1800),
    "max_plan_tasks": _require_positive("RUN_MAX_PLAN_TASKS", _get_env_int("RUN_MAX_PLAN_TASKS", 8) or 8),
    "max_tool_calls": _require_positive("RUN_MAX_TOOL_CALLS", _get_env_int("RUN_MAX_TOOL_CALLS", 30) or 30),
    "max_tavily_calls": _require_positive("RUN_MAX_TAVILY_CALLS", _get_env_int("RUN_MAX_TAVILY_CALLS", 20) or 20),
    "max_replans": _require_positive("RUN_MAX_REPLANS", _get_env_int("RUN_MAX_REPLANS", 2) or 2),
    "max_task_retries": _require_positive("RUN_MAX_TASK_RETRIES", _get_env_int("RUN_MAX_TASK_RETRIES", 2) or 2),
    "max_llm_tokens": _require_positive("RUN_MAX_LLM_TOKENS", _get_env_int("RUN_MAX_LLM_TOKENS", 200000) or 200000),
    "max_concurrency": _require_positive("RUN_MAX_CONCURRENCY", _get_env_int("RUN_MAX_CONCURRENCY", 4) or 4),
    "tool_timeout_seconds": _require_positive("RUN_TOOL_TIMEOUT_SECONDS", _get_env_int("RUN_TOOL_TIMEOUT_SECONDS", 60) or 60),
}

# ===== 知识图谱配置 =====

theme = "临床药物治疗学"  # 知识图谱主题

entity_types = [
    "疾病",
    "症状",
    "体征",
    "药物",
    "用药方案",
    "剂量",
    "给药途径",
    "不良反应",
    "禁忌症",
    "检验指标",
    "检查项目",
    "治疗手段",
    "指南/共识",
    "人群/亚组"
]

relationship_types = [
    "治疗",
    "适应症",
    "禁忌",
    "不良反应",
    "相互作用",
    "剂量调整",
    "给药途径",
    "联合用药",
    "替代/对照",
    "推荐",
    "监测",
    "依从性",
    "影响"
]


# theme = "华东理工大学学生管理"  # 知识图谱主题
#
# entity_types = [
#     "学生类型",
#     "奖学金类型",
#     "处分类型",
#     "部门",
#     "学生职责",
#     "管理规定",
# ]  # 知识图谱实体类型
#
# relationship_types = [
#     "申请",
#     "评选",
#     "违纪",
#     "资助",
#     "申诉",
#     "管理",
#     "权利义务",
#     "互斥",
# ]  # 知识图谱关系类型


# 冲突解决策略：manual_first / auto_first / merge
conflict_strategy = os.getenv("GRAPH_CONFLICT_STRATEGY", "manual_first")

# 社区检测算法：leiden / sllpa
community_algorithm = os.getenv("GRAPH_COMMUNITY_ALGORITHM", "leiden")

# ===== 文本处理配置 =====

CHUNK_SIZE = _get_env_int("CHUNK_SIZE", 500) or 500  # 文本分块大小
OVERLAP = _get_env_int("CHUNK_OVERLAP", 100) or 100  # 分块重叠长度
MAX_TEXT_LENGTH = _get_env_int("MAX_TEXT_LENGTH", 500000) or 500000  # 最大文本长度
similarity_threshold = _get_env_float("SIMILARITY_THRESHOLD", 0.9) or 0.9  # 向量相似度阈值

# ===== 回答生成配置 =====

response_type = os.getenv("RESPONSE_TYPE", "多个段落")  # 默认回答形式

# ===== Agent 工具描述 =====

lc_description = (
    "用于需要具体细节的查询。检索华东理工大学学生管理文件中的具体规定、条款、流程等详细内容。"
    "适用于'某个具体规定是什么'、'处理流程如何'等问题。"
)
gl_description = (
    "用于需要总结归纳的查询。分析华东理工大学学生管理体系的整体框架、管理原则、学生权利义务等宏观内容。"
    "适用于'学校的学生管理总体思路'、'学生权益保护机制'等需要系统性分析的问题。"
)
naive_description = (
    "基础检索工具，直接查找与问题最相关的文本片段，不做复杂分析。快速获取华东理工大学相关政策，返回最匹配的原文段落。"
)

examples = [
    "旷课多少学时会被退学？",
    "国家奖学金和国家励志奖学金互斥吗？",
    "优秀学生要怎么申请？",
    "那上海市奖学金呢？",
]  # 前端示例问题

# ===== 性能优化配置 =====

MAX_WORKERS = _get_env_int("MAX_WORKERS", 4) or 4  # 并行工作线程数
BATCH_SIZE = _get_env_int("BATCH_SIZE", 100) or 100  # 批处理大小
ENTITY_BATCH_SIZE = _get_env_int("ENTITY_BATCH_SIZE", 50) or 50  # 实体批次大小
CHUNK_BATCH_SIZE = _get_env_int("CHUNK_BATCH_SIZE", 100) or 100  # 文本块批次
EMBEDDING_BATCH_SIZE = _get_env_int("EMBEDDING_BATCH_SIZE", 64) or 64  # 向量批次
LLM_BATCH_SIZE = _get_env_int("LLM_BATCH_SIZE", 5) or 5  # LLM 批次
COMMUNITY_BATCH_SIZE = _get_env_int("COMMUNITY_BATCH_SIZE", 50) or 50  # 社区批次大小

# ===== GDS 相关配置 =====

GDS_MEMORY_LIMIT = _get_env_int("GDS_MEMORY_LIMIT", 6) or 6  # GDS 内存限制(GB)
GDS_CONCURRENCY = _get_env_int("GDS_CONCURRENCY", 4) or 4  # GDS 并发度
GDS_NODE_COUNT_LIMIT = _get_env_int("GDS_NODE_COUNT_LIMIT", 50000) or 50000  # 节点上限
GDS_TIMEOUT_SECONDS = _get_env_int("GDS_TIMEOUT_SECONDS", 300) or 300  # 超时时长

# ===== 实体消歧与对齐配置 =====

DISAMBIG_STRING_THRESHOLD = _get_env_float("DISAMBIG_STRING_THRESHOLD", 0.7) or 0.7
DISAMBIG_VECTOR_THRESHOLD = _get_env_float("DISAMBIG_VECTOR_THRESHOLD", 0.85) or 0.85
DISAMBIG_NIL_THRESHOLD = _get_env_float("DISAMBIG_NIL_THRESHOLD", 0.6) or 0.6
DISAMBIG_TOP_K = _get_env_int("DISAMBIG_TOP_K", 5) or 5

ALIGNMENT_CONFLICT_THRESHOLD = (
    _get_env_float("ALIGNMENT_CONFLICT_THRESHOLD", 0.5) or 0.5
)
ALIGNMENT_MIN_GROUP_SIZE = _get_env_int("ALIGNMENT_MIN_GROUP_SIZE", 2) or 2

# ===== 路径与缓存配置 =====

DEFAULT_CACHE_ROOT = Path(
    os.getenv("CACHE_ROOT", PROJECT_ROOT / "cache")
).expanduser()
MODEL_CACHE_ROOT = Path(
    os.getenv("MODEL_CACHE_ROOT", DEFAULT_CACHE_ROOT)
).expanduser()
MODEL_CACHE_DIR = MODEL_CACHE_ROOT / "model"
CACHE_DIR = Path(os.getenv("CACHE_DIR", DEFAULT_CACHE_ROOT)).expanduser()
TIKTOKEN_CACHE_DIR = Path(
    os.getenv("TIKTOKEN_CACHE_DIR", DEFAULT_CACHE_ROOT / "tiktoken")
).expanduser()
os.environ.setdefault("TIKTOKEN_CACHE_DIR", str(TIKTOKEN_CACHE_DIR))

SENTENCE_TRANSFORMER_MODELS = [
    item.strip()
    for item in os.getenv("SENTENCE_TRANSFORMER_MODELS", "").split(",")
    if item.strip()
]  # 预加载的本地模型列表
CACHE_EMBEDDING_PROVIDER = os.getenv(
    "CACHE_EMBEDDING_PROVIDER", "sentence_transformer"
).lower()
CACHE_SENTENCE_TRANSFORMER_MODEL = os.getenv(
    "CACHE_SENTENCE_TRANSFORMER_MODEL", "all-MiniLM-L6-v2"
)

CACHE_SETTINGS = {
    "dir": CACHE_DIR,
    "memory_only": _get_env_bool("CACHE_MEMORY_ONLY", False),
    "max_memory_size": _get_env_int("CACHE_MAX_MEMORY_SIZE", 100) or 100,
    "max_disk_size": _get_env_int("CACHE_MAX_DISK_SIZE", 1000) or 1000,
    "thread_safe": _get_env_bool("CACHE_THREAD_SAFE", True),
    "enable_vector_similarity": _get_env_bool(
        "CACHE_ENABLE_VECTOR_SIMILARITY", True
    ),
    "similarity_threshold": _get_env_float(
        "CACHE_SIMILARITY_THRESHOLD", similarity_threshold
    )
    or similarity_threshold,
    "max_vectors": _get_env_int("CACHE_MAX_VECTORS", 10000) or 10000,
}

# ===== Neo4j 连接配置 =====

NEO4J_URI = os.getenv("NEO4J_URI", "")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME", "")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")
NEO4J_MAX_POOL_SIZE = _get_env_int("NEO4J_MAX_POOL_SIZE", 10) or 10
NEO4J_REFRESH_SCHEMA = _get_env_bool("NEO4J_REFRESH_SCHEMA", False)

NEO4J_CONFIG = {
    "uri": NEO4J_URI,
    "username": NEO4J_USERNAME,
    "password": NEO4J_PASSWORD,
    "max_pool_size": NEO4J_MAX_POOL_SIZE,
    "refresh_schema": NEO4J_REFRESH_SCHEMA,
}

# ===== LLM 与嵌入模型配置 =====

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "")
OPENAI_EMBEDDINGS_MODEL = os.getenv("OPENAI_EMBEDDINGS_MODEL") or None
OPENAI_EMBEDDING_DIMENSIONS = _get_env_int("OPENAI_EMBEDDING_DIMENSIONS", None)
if OPENAI_EMBEDDING_DIMENSIONS is not None:
    OPENAI_EMBEDDING_DIMENSIONS = _require_positive(
        "OPENAI_EMBEDDING_DIMENSIONS", OPENAI_EMBEDDING_DIMENSIONS
    )
OPENAI_EMBEDDING_BATCH_SIZE = _require_positive(
    "OPENAI_EMBEDDING_BATCH_SIZE",
    _get_env_int("OPENAI_EMBEDDING_BATCH_SIZE", 10) or 10,
)
OPENAI_LLM_MODEL = os.getenv("OPENAI_LLM_MODEL") or None
MEMORY_LLM_MODEL = os.getenv("MEMORY_LLM_MODEL") or OPENAI_LLM_MODEL
MEMORY_LLM_MIN_CONFIDENCE = _get_env_float("MEMORY_LLM_MIN_CONFIDENCE", 0.75) or 0.75
if not 0.0 <= MEMORY_LLM_MIN_CONFIDENCE <= 1.0:
    raise ValueError("MEMORY_LLM_MIN_CONFIDENCE 必须在 0 到 1 之间")
MEMORY_LLM_MAX_CANDIDATES = _require_positive(
    "MEMORY_LLM_MAX_CANDIDATES", _get_env_int("MEMORY_LLM_MAX_CANDIDATES", 3) or 3,
)
MEMORY_LLM_MAX_MESSAGE_CHARS = _require_positive(
    "MEMORY_LLM_MAX_MESSAGE_CHARS", _get_env_int("MEMORY_LLM_MAX_MESSAGE_CHARS", 4000) or 4000,
)
MEMORY_LLM_MAX_OUTPUT_TOKENS = _require_positive(
    "MEMORY_LLM_MAX_OUTPUT_TOKENS", _get_env_int("MEMORY_LLM_MAX_OUTPUT_TOKENS", 1200) or 1200,
)
LLM_TEMPERATURE = _get_env_float("TEMPERATURE", None)
LLM_MAX_TOKENS = _get_env_int("MAX_TOKENS", None)
LLM_REQUEST_TIMEOUT_SECONDS = _require_positive(
    "LLM_REQUEST_TIMEOUT_SECONDS", _get_env_int("LLM_REQUEST_TIMEOUT_SECONDS", 90) or 90,
)
LLM_MAX_RETRIES = max(0, _get_env_int("LLM_MAX_RETRIES", 1) or 0)

OPENAI_EMBEDDING_CONFIG = {
    "model": OPENAI_EMBEDDINGS_MODEL,
    "api_key": OPENAI_API_KEY,
    "base_url": OPENAI_BASE_URL,
    "dimensions": OPENAI_EMBEDDING_DIMENSIONS,
    "chunk_size": OPENAI_EMBEDDING_BATCH_SIZE,
}

OPENAI_LLM_CONFIG = {
    "model": OPENAI_LLM_MODEL,
    "temperature": LLM_TEMPERATURE,
    "max_tokens": LLM_MAX_TOKENS,
    "api_key": OPENAI_API_KEY,
    "base_url": OPENAI_BASE_URL,
    "timeout": LLM_REQUEST_TIMEOUT_SECONDS,
    "max_retries": LLM_MAX_RETRIES,
}

# ===== 相似实体检测参数 =====

SIMILAR_ENTITY_SETTINGS = {
    "word_edit_distance": _get_env_int("SIMILAR_ENTITY_WORD_EDIT_DISTANCE", 3) or 3,
    "batch_size": _get_env_int("SIMILAR_ENTITY_BATCH_SIZE", 500) or 500,
    "memory_limit": _get_env_int(
        "SIMILAR_ENTITY_MEMORY_LIMIT", GDS_MEMORY_LIMIT
    )
    or GDS_MEMORY_LIMIT,
    "top_k": _get_env_int("SIMILAR_ENTITY_TOP_K", 10) or 10,
}

# ===== 搜索工具配置 =====

BASE_SEARCH_CONFIG = {
    "cache_max_size": _get_env_int("SEARCH_CACHE_MEMORY_SIZE", 200) or 200,
    "vector_limit": _get_env_int("SEARCH_VECTOR_LIMIT", 5) or 5,
    "text_limit": _get_env_int("SEARCH_TEXT_LIMIT", 5) or 5,
    "semantic_top_k": _get_env_int("SEARCH_SEMANTIC_TOP_K", 5) or 5,
    "relevance_top_k": _get_env_int("SEARCH_RELEVANCE_TOP_K", 5) or 5,
}

LOCAL_SEARCH_SETTINGS = {
    "top_chunks": _get_env_int("LOCAL_SEARCH_TOP_CHUNKS", 3) or 3,
    "top_communities": _get_env_int("LOCAL_SEARCH_TOP_COMMUNITIES", 3) or 3,
    "top_outside_relationships": _get_env_int(
        "LOCAL_SEARCH_TOP_OUTSIDE_RELS", 10
    )
    or 10,
    "top_inside_relationships": _get_env_int(
        "LOCAL_SEARCH_TOP_INSIDE_RELS", 10
    )
    or 10,
    "top_entities": _get_env_int("LOCAL_SEARCH_TOP_ENTITIES", 10) or 10,
    "index_name": os.getenv("LOCAL_SEARCH_INDEX_NAME", "vector"),
}

GLOBAL_SEARCH_SETTINGS = {
    "default_level": _get_env_int("GLOBAL_SEARCH_LEVEL", 0) or 0,
    "community_batch_size": _get_env_int("GLOBAL_SEARCH_BATCH_SIZE", 5) or 5,
}

NAIVE_SEARCH_TOP_K = _get_env_int("NAIVE_SEARCH_TOP_K", 3) or 3

HYBRID_SEARCH_SETTINGS = {
    "entity_limit": _get_env_int("HYBRID_SEARCH_ENTITY_LIMIT", 15) or 15,
    "max_hop_distance": _get_env_int("HYBRID_SEARCH_MAX_HOP", 2) or 2,
    "top_communities": _get_env_int("HYBRID_SEARCH_TOP_COMMUNITIES", 3) or 3,
    "batch_size": _get_env_int("HYBRID_SEARCH_BATCH_SIZE", 10) or 10,
    "community_level": _get_env_int("HYBRID_SEARCH_COMMUNITY_LEVEL", 0) or 0,
}

# ===== Agent 配置 =====

AGENT_SETTINGS = {
    "default_recursion_limit": _get_env_int("AGENT_RECURSION_LIMIT", 5) or 5,
    "chunk_size": _get_env_int("AGENT_CHUNK_SIZE", 4) or 4,
    "stream_flush_threshold": _get_env_int("AGENT_STREAM_FLUSH_THRESHOLD", 40)
    or 40,
    "deep_stream_flush_threshold": _get_env_int(
        "DEEP_AGENT_STREAM_FLUSH_THRESHOLD", 80
    )
    or 80,
    "fusion_stream_flush_threshold": _get_env_int(
        "FUSION_AGENT_STREAM_FLUSH_THRESHOLD", 60
    )
    or 60,
}

# ===== 多智能体（Plan-Execute-Report）配置 =====

MULTI_AGENT_PLANNER_MAX_TASKS = _get_env_int("MA_PLANNER_MAX_TASKS", 6) or 6
MULTI_AGENT_ALLOW_UNCLARIFIED_PLAN = _get_env_bool("MA_ALLOW_UNCLARIFIED_PLAN", True)
MULTI_AGENT_DEFAULT_DOMAIN = os.getenv("MA_DEFAULT_DOMAIN", "通用")

MULTI_AGENT_AUTO_GENERATE_REPORT = _get_env_bool("MA_AUTO_GENERATE_REPORT", True)
MULTI_AGENT_STOP_ON_CLARIFICATION = _get_env_bool("MA_STOP_ON_CLARIFICATION", True)
MULTI_AGENT_STRICT_PLAN_SIGNAL = _get_env_bool("MA_STRICT_PLAN_SIGNAL", True)

MULTI_AGENT_DEFAULT_REPORT_TYPE = os.getenv("MA_DEFAULT_REPORT_TYPE", "long_document")
MULTI_AGENT_ENABLE_CONSISTENCY_CHECK = _get_env_bool(
    "MA_ENABLE_CONSISTENCY_CHECK", True
)
MULTI_AGENT_ENABLE_MAPREDUCE = _get_env_bool("MA_ENABLE_MAPREDUCE", True)
MULTI_AGENT_MAPREDUCE_THRESHOLD = _get_env_int("MA_MAPREDUCE_THRESHOLD", 20) or 20
MULTI_AGENT_MAX_TOKENS_PER_REDUCE = (
    _get_env_int("MA_MAX_TOKENS_PER_REDUCE", 4000) or 4000
)
MULTI_AGENT_ENABLE_PARALLEL_MAP = _get_env_bool("MA_ENABLE_PARALLEL_MAP", True)

MULTI_AGENT_SECTION_MAX_EVIDENCE = (
    _get_env_int("MA_SECTION_MAX_EVIDENCE", 8) or 8
)
MULTI_AGENT_SECTION_MAX_CONTEXT_CHARS = (
    _get_env_int("MA_SECTION_MAX_CONTEXT_CHARS", 800) or 800
)
LEARNING_REVIEW_ENABLED = _get_env_bool("LEARNING_REVIEW_ENABLED", True)
LEARNING_REVIEW_MODEL = os.getenv("LEARNING_REVIEW_MODEL") or OPENAI_LLM_MODEL
LEARNING_REVIEW_MAX_OUTPUT_TOKENS = _require_positive(
    "LEARNING_REVIEW_MAX_OUTPUT_TOKENS", _get_env_int("LEARNING_REVIEW_MAX_OUTPUT_TOKENS", 4000) or 4000,
)
LEARNING_REVIEW_MAX_RETRIES = max(0, _get_env_int("LEARNING_REVIEW_MAX_RETRIES", 2) or 0)
SKILL_WRITE_APPROVAL_REQUIRED = _get_env_bool("SKILL_WRITE_APPROVAL_REQUIRED", True)
SKILL_CANARY_INITIAL_PERCENT = max(1, min(50, _get_env_int("SKILL_CANARY_INITIAL_PERCENT", 5) or 5))
EVIDENCE_CARD_MAX_TOKENS = _get_env_int("EVIDENCE_CARD_MAX_TOKENS", 200) or 200
EVIDENCE_CARD_BATCH_SIZE = _get_env_int("EVIDENCE_CARD_BATCH_SIZE", 10) or 10
REPORT_SECTION_EVIDENCE_BUDGET = _get_env_int("REPORT_SECTION_EVIDENCE_BUDGET", 12000) or 12000
REPORT_BATCH_BUDGET_RATIO = _get_env_float("REPORT_BATCH_BUDGET_RATIO", 0.70) or 0.70
REPORT_BATCH_DIGEST_MAX_TOKENS = _get_env_int("REPORT_BATCH_DIGEST_MAX_TOKENS", 600) or 600
REPORT_MAX_SECTIONS = _get_env_int("REPORT_MAX_SECTIONS", 6) or 6
REPORT_MAX_MODEL_CALLS = _get_env_int("REPORT_MAX_MODEL_CALLS", 15) or 15
REPORT_RESERVED_TOKENS = _get_env_int("REPORT_RESERVED_TOKENS", 60000) or 60000
VERIFICATION_RESERVED_TOKENS = _get_env_int("VERIFICATION_RESERVED_TOKENS", 15000) or 15000
MULTI_AGENT_REFLECTION_ALLOW_RETRY = _get_env_bool(
    "MA_REFLECTION_ALLOW_RETRY", False
)
MULTI_AGENT_REFLECTION_MAX_RETRIES = (
    _get_env_int("MA_REFLECTION_MAX_RETRIES", 1) or 1
)
MULTI_AGENT_WORKER_EXECUTION_MODE = _get_env_choice(
    "MA_WORKER_EXECUTION_MODE",
    {"sequential", "parallel"},
    "sequential",
)
MULTI_AGENT_WORKER_MAX_CONCURRENCY = (
    _get_env_int("MA_WORKER_MAX_CONCURRENCY", MAX_WORKERS) or MAX_WORKERS
)
if MULTI_AGENT_WORKER_MAX_CONCURRENCY < 1:
    raise ValueError("MA_WORKER_MAX_CONCURRENCY 必须大于等于 1")
